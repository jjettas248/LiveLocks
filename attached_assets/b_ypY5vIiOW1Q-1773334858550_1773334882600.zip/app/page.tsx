"use client";

import { useState } from "react";
import { Zap, BarChart3, Target, ArrowRight, CheckCircle2, TrendingUp, Shield, Activity, MessageSquare, Bell } from "lucide-react";
import { DashboardPreview } from "@/components/DashboardPreview";
import Image from "next/image";

export default function Home() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.includes("@")) {
      setSubmitted(true);
      setEmail("");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans antialiased selection:bg-blue-500/20">

      {/* Light hero zone */}
      <div className="bg-white text-gray-950">

        {/* Navigation */}
        <nav className="sticky top-0 z-50 border-b border-gray-200 bg-white/80 backdrop-blur-md">
          <div className="container mx-auto px-6 h-14 flex items-center justify-between max-w-6xl">
            <div className="flex items-center gap-2">
              <Image
                src="/favicon.jpg"
                alt="LiveLocks logo"
                width={28}
                height={28}
                className="rounded-md"
              />
              <span className="font-bold text-gray-950 tracking-tight">
                livelocksai<span className="text-blue-600">.app</span>
              </span>
            </div>
            <div className="hidden md:flex items-center gap-8 text-sm text-gray-500">
              <a href="#features" className="hover:text-gray-900 transition-colors">Features</a>
              <a href="#preview" className="hover:text-gray-900 transition-colors">Dashboard</a>
              <a href="#alerts" className="hover:text-gray-900 transition-colors">Alerts</a>
            </div>
            <a
              href="#waitlist"
              className="flex items-center gap-1.5 bg-gray-950 text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors"
            >
              Get Access <ArrowRight size={14} />
            </a>
          </div>
        </nav>

        {/* Hero Section */}
        <header className="container mx-auto px-6 pt-24 pb-20 text-center max-w-5xl flex flex-col items-center">
          <div className="inline-flex items-center gap-2 bg-gray-100 border border-gray-200 text-gray-500 px-3 py-1.5 rounded-full text-xs font-medium mb-10 tracking-wide">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500" />
            </span>
            Detection engine is live — NBA season active
          </div>

          <h1 className="text-6xl md:text-8xl font-extrabold tracking-tighter mb-6 leading-none text-balance text-gray-950">
            Stop guessing<br />on live props.
          </h1>

          <p className="text-lg text-gray-500 mb-12 max-w-xl mx-auto leading-relaxed text-pretty">
            LiveLocks scans every halftime game simultaneously, ranks the highest-edge 2H props using real-time box score data, and texts you the top plays the moment they are detected.
          </p>

          {/* Waitlist Capture */}
          <div id="waitlist" className="w-full max-w-md mx-auto mb-5">
            {!submitted ? (
              <form
                onSubmit={handleJoin}
                className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1.5 focus-within:border-blue-400 transition-colors shadow-md shadow-black/5"
              >
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="Enter your email address"
                  className="bg-transparent text-gray-900 placeholder:text-gray-400 px-3 py-2.5 w-full focus:outline-none text-sm"
                />
                <button
                  type="submit"
                  className="shrink-0 bg-gray-950 text-white text-sm font-semibold px-5 py-2.5 rounded-lg hover:bg-gray-800 transition-colors whitespace-nowrap"
                >
                  Get Access
                </button>
              </form>
            ) : (
              <div className="flex items-center justify-center gap-2 bg-gray-100 border border-gray-200 p-4 rounded-xl text-gray-600 font-medium animate-in fade-in zoom-in duration-300">
                <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                <span>{"You're in. Check your inbox — 15 free calculations are waiting."}</span>
              </div>
            )}
          </div>

          {!submitted && (
            <p className="text-xs text-gray-400">
              No credit card required &middot; 15 free probability calculations included
            </p>
          )}
        </header>

      </div>{/* end light hero zone */}

      {/* Dashboard Preview */}
      <section id="preview" className="container mx-auto px-6 pb-32 max-w-6xl">
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-widest text-muted-foreground/50">
            <div className="h-px w-16 bg-border" />
            Live Dashboard
            <div className="h-px w-16 bg-border" />
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-4 bg-blue-600/5 blur-3xl rounded-3xl pointer-events-none" />
          <div className="relative rounded-2xl border border-border overflow-hidden shadow-2xl shadow-black/60">
            {/* Fake browser bar */}
            <div className="flex items-center gap-2 px-4 py-3 bg-secondary border-b border-border">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-border" />
                <div className="w-3 h-3 rounded-full bg-border" />
                <div className="w-3 h-3 rounded-full bg-border" />
              </div>
              <div className="flex-1 flex justify-center">
                <div className="bg-card border border-border rounded-md px-4 py-1 text-xs text-muted-foreground/50 font-mono w-52 text-center">
                  livelocksai.app
                </div>
              </div>
            </div>
            <DashboardPreview />
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent rounded-b-2xl pointer-events-none" />
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="container mx-auto px-6 py-24 max-w-6xl border-t border-border">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground mb-4 text-balance">
            Built for in-game edge.
          </h2>
          <p className="text-muted-foreground text-base max-w-md mx-auto leading-relaxed">
            Every feature is designed around one goal: giving you a sharper read on live props faster than anyone else at halftime.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <FeatureCard
            icon={<Zap size={20} className="text-blue-400" />}
            iconBg="bg-blue-500/10"
            title="Proprietary Live Prediction Engine"
            body="Our detection software combines live box score data, pace, opponent defense, and foul trouble into a single hit probability — updated every play, not just at halftime."
          />
          <FeatureCard
            icon={<BarChart3 size={20} className="text-emerald-400" />}
            iconBg="bg-emerald-500/10"
            title="Live Box Auto-Fill"
            body="Stop toggling screens. Clickable live box scores instantly load player data into the calculator — minutes played, fouls, and halftime score auto-populated."
          />
          <FeatureCard
            icon={<Target size={20} className="text-blue-400" />}
            iconBg="bg-blue-500/10"
            title="Smart Parlay Builder"
            body="Add any detected play directly to your parlay slip. Built-in correlation awareness and live sportsbook line integration keep your slip grounded in reality."
          />
        </div>
      </section>

      {/* How 2H Plays Are Detected */}
      <section className="container mx-auto px-6 py-24 max-w-6xl border-t border-border">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Left: copy */}
          <div>
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-widest mb-6">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-blue-400" />
              </span>
              Live Detection Engine
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground mb-5 text-balance">
              Top 2H plays, ranked the moment halftime hits.
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8 text-pretty">
              The detection engine is live and running every NBA game night. At halftime it scans the full slate simultaneously — comparing H1 observed stats against projected 2H baselines to surface the highest-edge props before lines move.
            </p>
            <ul className="space-y-4">
              {[
                {
                  icon: <TrendingUp size={15} className="text-emerald-400" />,
                  bg: "bg-emerald-500/10",
                  title: "Probability edge scoring",
                  body: "Each play is ranked by the gap between the model's hit probability and the book-implied odds — the wider the gap, the higher the rank.",
                },
                {
                  icon: <Shield size={15} className="text-blue-400" />,
                  bg: "bg-blue-500/10",
                  title: "Live Line vs Season Avg transparency",
                  body: "Every card clearly labels whether the line is live-adjusted or a season-average baseline so you always know the data source behind the call.",
                },
                {
                  icon: <Zap size={15} className="text-amber-400" />,
                  bg: "bg-amber-500/10",
                  title: "One-click parlay building",
                  body: "Add any ranked play directly to your parlay slip without leaving the view. Lines stay live so your slip reflects current market prices.",
                },
              ].map(({ icon, bg, title, body }) => (
                <li key={title} className="flex items-start gap-3">
                  <div className={`${bg} w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5`}>
                    {icon}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{title}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

          {/* Right: screenshot */}
          <div className="relative rounded-xl overflow-hidden border border-border shadow-2xl shadow-black/60">
            <Image
              src="/top-2h-plays.png"
              alt="Top 2H Plays — Full Slate dashboard showing ranked play cards with probability edges"
              width={1400}
              height={600}
              className="w-full h-auto"
            />
            <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-background/80 to-transparent pointer-events-none" />
          </div>
        </div>
      </section>

      {/* SMS Alerts Section */}
      <section id="alerts" className="container mx-auto px-6 py-24 max-w-6xl border-t border-border">
        <div className="grid md:grid-cols-2 gap-16 items-center">

          {/* Left: built phone mockup with accurate data */}
          <div className="flex flex-col items-center gap-4">
            <div className="w-72 bg-[#1a1a1a] border border-white/[0.08] rounded-3xl p-5 shadow-2xl shadow-black/70 font-sans">
              {/* Status bar */}
              <div className="flex justify-between items-center text-white/30 text-xs font-mono mb-5 px-1">
                <span>9:41 AM</span>
                <div className="flex items-center gap-1">
                  <div className="w-4 h-2 border border-white/20 rounded-sm"><div className="h-full w-3/4 bg-white/30 rounded-sm" /></div>
                </div>
              </div>
              {/* Sender */}
              <div className="flex items-center gap-3 mb-5 px-1">
                <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center shrink-0">
                  <Bell size={15} className="text-white" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">LiveLocks Alerts</p>
                  <p className="text-xs text-white/35">livelocksai.app</p>
                </div>
              </div>
              {/* Alert 1 — Dennis Schroder */}
              <div className="bg-blue-600 text-white rounded-2xl rounded-tl-sm px-4 py-3.5 text-xs leading-relaxed mb-3">
                <p className="font-extrabold text-[11px] tracking-wide mb-1.5">HALFTIME ALERT — CLE vs DET</p>
                <p className="font-semibold mb-0.5">Dennis Schroder — Points U13.5</p>
                <p className="text-white/70 text-[11px]">H1: 6 pts · Proj 2H: 9.6 · Need: 7.5</p>
                <p className="font-bold text-emerald-300 mt-1.5 text-[11px]">Edge: +38.0% · Hit Prob: 86.7%</p>
              </div>
              {/* Alert 2 — Jalen Duren (replaces inaccurate Duncan Robinson 3PM) */}
              <div className="bg-blue-600 text-white rounded-2xl rounded-tl-sm px-4 py-3.5 text-xs leading-relaxed mb-3">
                <p className="font-extrabold text-[11px] tracking-wide mb-1.5">HALFTIME ALERT — CLE vs DET</p>
                <p className="font-semibold mb-0.5">Jalen Duren — Pts+Reb O34.5</p>
                <p className="text-white/70 text-[11px]">H1: 26 · Proj 2H: 17.8 · Need: 8.5</p>
                <p className="font-bold text-emerald-300 mt-1.5 text-[11px]">Edge: +35.1% · Hit Prob: 85.1%</p>
              </div>
              {/* Reply bubble */}
              <div className="ml-auto bg-[#2a2a2a] border border-white/[0.08] rounded-2xl rounded-tr-sm px-4 py-2.5 text-xs text-white/40 max-w-[70%] text-right">
                added both to parlay
              </div>
            </div>
            <p className="text-xs text-muted-foreground/50 text-center max-w-xs">
              Alerts fire the moment halftime data is confirmed. No refresh needed.
            </p>
          </div>

          {/* Right: copy */}
          <div>
            <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-widest mb-6">
              <MessageSquare size={11} />
              Real-Time SMS Alerts
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-foreground mb-5 text-balance">
              The best plays, texted to you at halftime.
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8 text-pretty">
              You do not need to have the dashboard open. The moment the engine detects a top-ranked play across any live game, it fires an SMS alert straight to your phone — player, prop, edge percentage, and hit probability included.
            </p>
            <ul className="space-y-4">
              {[
                {
                  icon: <Bell size={15} className="text-emerald-400" />,
                  bg: "bg-emerald-500/10",
                  title: "Fires at halftime automatically",
                  body: "No polling, no manual refresh. The engine pushes alerts the second halftime data is confirmed — before most bettors even open the app.",
                },
                {
                  icon: <Activity size={15} className="text-blue-400" />,
                  bg: "bg-blue-500/10",
                  title: "Full context in every message",
                  body: "Each alert includes the player name, prop line, H1 observed stats, projected 2H pace, edge percentage, and model hit probability.",
                },
                {
                  icon: <Shield size={15} className="text-amber-400" />,
                  bg: "bg-amber-500/10",
                  title: "Only the highest-edge plays",
                  body: "Alerts are throttled to the top-ranked plays by probability edge. You get signal, not noise.",
                },
              ].map(({ icon, bg, title, body }) => (
                <li key={title} className="flex items-start gap-3">
                  <div className={`${bg} w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5`}>
                    {icon}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{title}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>

        </div>
      </section>

      {/* CTA Banner */}
      <section className="container mx-auto px-6 pb-24 max-w-6xl">
        <div className="bg-secondary border border-border rounded-2xl p-12 text-center">
          <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-widest mb-6">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
            </span>
            Live Now — NBA 2025–26 Season
          </div>
          <h3 className="text-2xl md:text-3xl font-extrabold tracking-tight text-foreground mb-3 text-balance">
            Ready to find your edge?
          </h3>
          <p className="text-muted-foreground mb-8 max-w-sm mx-auto leading-relaxed">
            Get full access to the live detection engine, SMS halftime alerts, and the prop calculator. Includes 15 free probability calculations to get started.
          </p>
          <a
            href="#waitlist"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="inline-flex items-center gap-2 bg-foreground text-background font-semibold px-6 py-3 rounded-lg hover:bg-foreground/90 transition-colors"
          >
            Get Access — Free to Start <ArrowRight size={15} />
          </a>
          <p className="text-xs text-muted-foreground/50 mt-4">No credit card required &middot; 15 free calculations included</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="container mx-auto px-6 py-8 max-w-6xl flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-muted-foreground/50">
          <div className="flex items-center gap-2">
            <Image src="/favicon.jpg" alt="LiveLocks" width={18} height={18} className="rounded" />
            <span className="font-semibold text-muted-foreground">livelocksai.app</span>
          </div>
          <span>livelocksai.app &nbsp;&middot;&nbsp; &copy; {new Date().getFullYear()} LiveLocks AI. All rights reserved.</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-muted-foreground transition-colors">Privacy</a>
            <a href="#" className="hover:text-muted-foreground transition-colors">Terms</a>
            <a href="#" className="hover:text-muted-foreground transition-colors">Contact</a>
          </div>
        </div>
      </footer>

    </div>
  );
}

function FeatureCard({
  icon,
  iconBg,
  title,
  body,
}: {
  icon: React.ReactNode;
  iconBg: string;
  title: string;
  body: string;
}) {
  return (
    <div className="bg-secondary border border-border rounded-2xl p-7 flex flex-col gap-5 hover:border-border/80 hover:bg-card transition-colors group">
      <div className={`${iconBg} w-10 h-10 rounded-xl flex items-center justify-center`}>
        {icon}
      </div>
      <div>
        <h3 className="text-base font-bold text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
      </div>
    </div>
  );
}

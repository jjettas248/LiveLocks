"use client";

import { useState } from "react";
import {
  Activity,
  RefreshCw,
  Users,
  Zap,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  Clock,
  Shield,
  Settings,
  Star,
  CircleDot,
  ExternalLink,
  Copy,
  X,
  Twitter,
} from "lucide-react";

/* ─── TYPES ───────────────────────────────────────────────────────── */
type View = "v3" | "v4" | "plays";

/* ─── ROOT ────────────────────────────────────────────────────────── */
export function DashboardPreview() {
  const [view, setView] = useState<View>("v4");

  const views: { id: View; label: string; desc: string }[] = [
    { id: "v3", label: "Basic Prediction", desc: "Bilal Coulibaly · Pts+Reb" },
    { id: "v4", label: "Full Live Analysis", desc: "Jalen Duren · Pts+Reb" },
    { id: "plays", label: "Top 2H Plays", desc: "Full Slate" },
  ];

  return (
    <div className="w-full bg-[#080808] text-white font-sans select-none overflow-hidden">
      {/* Top Nav */}
      <div className="flex items-center justify-between px-5 py-3 bg-[#0f0f0f] border-b border-white/[0.08]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
            <Activity size={14} className="text-white" />
          </div>
          <div>
            <div className="font-extrabold text-[13px] tracking-tight leading-none text-white">LiveLocks</div>
            <div className="text-[9px] text-white/30 tracking-[0.15em] mt-0.5">BY PROPPULSE · NBA</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] font-semibold bg-emerald-400/10 border border-emerald-400/20 px-2.5 py-1 rounded-md">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
            </span>
            2 live games
          </div>
          <NavButton icon={<RefreshCw size={11} />} label="Sync Rosters" />
          <NavButton icon={<Users size={11} />} label="Parlay Slip" highlight />
          <NavButton icon={<Settings size={11} />} label="Admin" golden />
        </div>
      </div>

      {/* Live Box Score Bar */}
      <div className="flex items-center justify-between px-5 py-2.5 bg-[#0c0c0c] border-b border-white/[0.06]">
        <div className="flex items-center gap-2 text-[11px] font-bold text-white/70 tracking-[0.1em] uppercase">
          <Activity size={11} className="text-emerald-400" />
          Live Box Score
          <span className="text-white/25 font-normal normal-case tracking-normal">— click a row to auto-fill</span>
          <ChevronDown size={11} className="text-white/25" />
        </div>
        <div className="flex items-center gap-3 text-[11px] text-white/25">
          <span>Auto-refreshes every 2 min · Last: 05:01 PM</span>
          <div className="flex items-center gap-1 text-white/30">
            <RefreshCw size={10} /> Refresh
          </div>
        </div>
      </div>

      {/* View Switcher — prominent pill tabs */}
      <div className="flex items-center gap-3 px-5 py-3 bg-[#0d0d0d] border-b border-white/[0.08]">
        <span className="text-[10px] text-white/25 font-semibold uppercase tracking-widest shrink-0 pr-1">View:</span>
        {views.map((v) => (
          <button
            key={v.id}
            onClick={() => setView(v.id)}
            className={`pointer-events-auto cursor-pointer flex items-center gap-2 text-[11px] font-bold px-4 py-2 rounded-lg border transition-all ${
              view === v.id
                ? "bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/30"
                : "bg-white/[0.04] border-white/[0.10] text-white/50 hover:bg-white/[0.09] hover:text-white hover:border-white/[0.20]"
            }`}
          >
            {v.id === "plays" && <Star size={10} className={view === v.id ? "text-white" : "text-white/30"} />}
            <span>{v.label}</span>
            <span className={`text-[9px] font-normal rounded px-1.5 py-0.5 ${
              view === v.id ? "bg-white/20 text-white/80" : "bg-white/[0.06] text-white/25"
            }`}>
              {v.desc}
            </span>
          </button>
        ))}
        <div className="ml-auto flex items-center gap-1.5 text-[10px] text-white/20 select-none">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-white/20">
            <path d="M2 6h8M6 2l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span>click to switch views</span>
        </div>
      </div>

      {/* Content */}
      {view === "v3" && <V3Tab />}
      {view === "v4" && <V4Tab />}
      {view === "plays" && <TopPlaysTab />}
    </div>
  );
}

/* ─── V3: BILAL COULIBALY / PTS+REB / GREEN 84.4% GAUGE + BET SLIP ── */
function V3Tab() {
  const hitPct = 0.844;
  const r = 52;
  const circ = 2 * Math.PI * r;

  return (
    <div className="flex min-h-[560px]">
      {/* Left panel */}
      <div className="w-[270px] shrink-0 border-r border-white/[0.07] p-5 bg-[#0b0b0b] flex flex-col gap-4 overflow-y-auto">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="font-extrabold text-[14px] text-white leading-tight">Matchup Details</h2>
            <p className="text-[11px] text-white/30 mt-0.5">Enter halftime stats to calculate 2H probability.</p>
          </div>
          <div className="flex gap-1 shrink-0 mt-0.5">
            <Pill text="Rockets -16.5" />
            <Pill text="O/U 227.5" />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-[10px] text-white/35 font-medium tracking-wide uppercase">Player</label>
          </div>
          <SelectRow value="Bilal Coulibaly (SF)" />
        </div>

        <div>
          <label className="text-[10px] text-white/35 font-medium tracking-wide uppercase block mb-1.5">Opponent Team</label>
          <SelectRow value="HOU – Houston Rockets" />
        </div>

        <div className="bg-[#111111] border border-white/[0.07] rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center gap-2 text-[10px] font-bold text-white/35 tracking-[0.1em] uppercase">
            <Clock size={10} />
            Game Situation
            <span className="flex items-center gap-1 text-emerald-400 normal-case tracking-normal font-semibold text-[10px]">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
              </span>
              Auto-filled
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <InputField label="Minutes Played" value="13" highlight />
            <InputField label="Fouls" value="0" highlight />
          </div>
          <div>
            <div className="flex items-center gap-1 text-[10px] text-white/25 mb-1.5">
              <Zap size={9} className="text-yellow-400/70" />
              Halftime Score (optional)
            </div>
            <InputField label="" value="60-51" />
          </div>
        </div>

        <div className="bg-[#111111] border border-white/[0.07] rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-white/35 tracking-[0.1em] uppercase">
            <CircleDot size={10} />
            The Line
          </div>
          <div>
            <label className="text-[10px] text-white/25 block mb-1.5">Stat / Prop Type</label>
            <SelectRow value="Pts+Reb" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <InputField label="Current Stat Total" value="15" highlight />
            <InputField label="Live Line" value="19.5" blueHighlight />
          </div>
        </div>

        {/* Lines by Book */}
        <div className="bg-[#111111] border border-white/[0.07] rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between text-[10px] font-bold text-white/35 tracking-[0.1em] uppercase">
            <span>Lines by Book</span>
            <span className="flex items-center gap-1 text-emerald-400 normal-case tracking-normal font-normal text-[9px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" /> Live · 4m ago
              <RefreshCw size={9} className="text-white/20 ml-1" />
            </span>
          </div>
          {/* DraftKings row */}
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-white/70">DraftKings</span>
            <span className="font-bold text-blue-400 font-mono">20.5</span>
            <span className="text-white/30 font-mono text-[10px]">O -125 / U -105</span>
          </div>
          <div className="flex items-center justify-between text-[10px] text-white/25">
            <span>CLV vs your line</span>
            <span className="text-emerald-400 font-semibold">+1 pt</span>
          </div>
          <div className="border-t border-white/[0.05] pt-3">
            {/* Hard Rock highlighted */}
            <div className="bg-blue-600/[0.07] border border-blue-500/20 rounded-lg p-2.5">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="font-bold text-white">Hard Rock</span>
                <span className="font-bold text-blue-400 font-mono">19.5</span>
                <span className="text-white/30 font-mono text-[10px]">O -120 / U -115</span>
              </div>
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-white/25">Open: 18.5</span>
                <div className="flex items-center gap-1 text-red-400 font-semibold">
                  <TrendingDown size={9} /> Under edge <span className="font-mono">-2.5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Center panel */}
      <div className="flex-1 flex flex-col bg-[#080808] min-w-0">
        {/* Prediction header */}
        <div className="p-6 border-b border-white/[0.06]">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-[9px] font-bold text-white/25 tracking-[0.2em] uppercase mb-3">Live Prediction</div>
              <h3 className="text-[22px] font-extrabold text-white mb-2 leading-tight tracking-tight">
                Bilal Coulibaly <span className="text-white/25">—</span> Pts+Reb{" "}
                <span className="text-blue-400">19.5</span>
              </h3>
              <div className="flex items-center gap-2 text-[12px] text-white/35 mb-3">
                <TrendingUp size={12} className="text-white/20" />
                At half: <span className="font-bold text-white/80 mx-0.5">15</span>
                <span className="text-white/15">·</span>
                Needs <span className="font-bold text-white/80 mx-0.5">4.5</span> more
              </div>
              <div className="flex items-center gap-4 text-[11px] text-white/30 mb-5 font-mono">
                <span>Season: <span className="text-white/60 font-semibold">10.2</span> PPG</span>
                <span><span className="text-white/60 font-semibold">4.4</span> RPG</span>
                <span><span className="text-white/60 font-semibold">2.6</span> APG</span>
                <span><span className="text-white/60 font-semibold">26.0</span> MPG</span>
              </div>
              <div className="flex gap-2.5">
                <ProbButton label="Over 19.5" pct="84%" positive />
                <ProbButton label="Under 19.5" pct="16%" positive={false} />
              </div>
            </div>

            {/* Green gauge */}
            <div className="relative shrink-0">
              <svg width="130" height="130" viewBox="0 0 130 130" className="-rotate-90">
                <circle cx="65" cy="65" r={r} fill="none" stroke="#ffffff06" strokeWidth="10" />
                <circle
                  cx="65" cy="65" r={r}
                  fill="none"
                  stroke="#22c55e"
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={circ}
                  strokeDashoffset={circ * (1 - hitPct)}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[26px] font-extrabold text-emerald-400 leading-none tracking-normal font-sans">84.4%</span>
                <span className="text-[9px] text-white/25 uppercase tracking-[0.15em] mt-1">Hit Implied</span>
              </div>
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[9px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap">
                +30% EV
              </div>
            </div>
          </div>
        </div>

        {/* 5 Stat Cards */}
        <div className="grid grid-cols-5 divide-x divide-white/[0.05] border-b border-white/[0.06]">
          <StatCard label="Expected Total" value="28.1" valueClass="text-emerald-400" sub="Need: 19.5" icon={<CircleIcon />} />
          <StatCard label="Proj. Remaining Min" value="13.0" valueClass="text-white" sub="Full-Game Baseline" icon={<Clock size={12} className="text-white/20" />} />
          <StatCard label="Defense vs Pos" value="-3.0%" valueClass="text-red-400" sub="Opp allow vs position" icon={<Shield size={12} className="text-white/20" />} />
          <StatCard label="Game Pace" value="Above Avg" valueClass="text-white" valueSize="text-[14px]" sub="100 vs 103 pos/48" icon={<Zap size={12} className="text-white/20" />} />
          <StatCard label="vs Market" value="+29.9%" valueClass="text-emerald-400" sub="Model vs implied odds" icon={<TrendingUp size={12} className="text-white/20" />} />
        </div>

        {/* Strong pick banner */}
        <div className="mx-5 mt-5 bg-[#111111] border border-white/[0.09] rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[15px]">🔥</span>
            <span className="text-[12px] font-bold text-white">Strong pick detected</span>
          </div>
          <p className="text-[11px] text-white/35 mb-3 font-mono">
            🔥 Bilal Coulibaly Over 19.5 Pts+Reb — 84.4% likely by @proppulsebets #LiveLocks
          </p>
          <div className="flex items-center gap-2">
            <button className="pointer-events-auto flex-1 flex items-center justify-center gap-2 text-[11px] font-semibold text-white bg-[#1a1a1a] border border-white/[0.12] rounded-lg py-2 hover:bg-white/[0.06] transition-colors">
              <Twitter size={12} className="text-white/60" /> Tweet this pick
            </button>
            <button className="pointer-events-auto w-8 h-8 flex items-center justify-center bg-[#1a1a1a] border border-white/[0.12] rounded-lg hover:bg-white/[0.06] transition-colors">
              <Copy size={12} className="text-white/40" />
            </button>
          </div>
        </div>

        {/* Live Pace Active */}
        <div className="mx-5 mt-3 mb-5 flex items-start gap-3 bg-yellow-500/[0.06] border border-yellow-500/[0.15] rounded-xl p-3.5">
          <Zap size={13} className="text-yellow-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-[11px] font-bold text-yellow-400">Live Pace Active</p>
            <p className="text-[10px] text-white/30 mt-0.5">
              Score 60-51 blended with team history → above avg game (-1.0% vs league avg).
            </p>
          </div>
        </div>
      </div>

      {/* Right panel: Straight Bet slip */}
      <div className="w-[230px] shrink-0 border-l border-white/[0.07] bg-[#0b0b0b] flex flex-col">
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.07]">
          <div className="flex items-center gap-1.5">
            <Zap size={11} className="text-yellow-400" />
            <span className="text-[12px] font-bold text-white">Straight Bet</span>
          </div>
          <button className="pointer-events-auto text-[10px] text-white/30 flex items-center gap-0.5 hover:text-white/60 transition-colors">
            <X size={10} /> Clear All
          </button>
        </div>

        <div className="p-4 border-b border-white/[0.07]">
          <div className="flex items-start justify-between mb-2">
            <div>
              <p className="text-[12px] font-bold text-white">Bilal Coulibaly</p>
              <p className="text-[10px] text-white/35 font-mono">WAS</p>
            </div>
            <button className="pointer-events-auto text-white/20 hover:text-white/50 transition-colors">
              <X size={11} />
            </button>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[10px] font-bold bg-emerald-500/15 border border-emerald-500/25 text-emerald-400 px-1.5 py-0.5 rounded">PR O19.5</span>
            <span className="text-[10px] text-white/30">Hard Rock Bet (-120)</span>
            <span className="ml-auto text-[11px] font-bold text-emerald-400 font-mono">84.4%</span>
          </div>
        </div>

        <div className="p-4 border-b border-white/[0.07] flex flex-col gap-3">
          <div className="flex items-center justify-between text-[10px] text-white/35 uppercase tracking-widest font-bold">
            <span>Sportsbook Odds</span>
            <span className="text-[18px] font-extrabold text-white font-mono normal-case tracking-tight">-120</span>
          </div>
        </div>

        <div className="p-4 border-b border-white/[0.07] flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-white/35 uppercase tracking-widest">Send Straight to Sportsbook</p>
            <button className="pointer-events-auto flex items-center gap-1 text-[9px] text-white/25 border border-white/[0.08] bg-white/[0.03] px-1.5 py-0.5 rounded hover:text-white/50 transition-colors">
              <Copy size={8} /> Copy
            </button>
          </div>
          <p className="text-[10px] text-white/25 leading-relaxed">
            Opens player props — your pick is copied to clipboard automatically.
          </p>
        </div>

        <div className="p-4 flex flex-col gap-2">
          <button className="pointer-events-auto w-full flex items-center justify-center gap-2 text-[11px] font-bold text-black bg-yellow-400 hover:bg-yellow-300 transition-colors rounded-lg py-2.5">
            Hard Rock Bet <ExternalLink size={11} />
          </button>
          <button className="pointer-events-auto w-full flex items-center justify-between text-[11px] font-semibold text-white bg-emerald-600/80 hover:bg-emerald-600 transition-colors rounded-lg px-3 py-2.5">
            <span>Bet365</span>
            <span className="text-[10px] font-normal text-white/60">Search player name manually</span>
            <ExternalLink size={11} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── V4: JALEN DUREN / PTS+REB / BLUE 44.5% GAUGE ──────────────── */
function V4Tab() {
  const hitPct = 0.445;
  const r = 52;
  const circ = 2 * Math.PI * r;

  return (
    <div className="flex min-h-[520px]">
      {/* Left */}
      <div className="w-[270px] shrink-0 border-r border-white/[0.07] p-5 bg-[#0b0b0b] flex flex-col gap-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="font-extrabold text-[14px] text-white leading-tight">Matchup Details</h2>
            <p className="text-[11px] text-white/30 mt-0.5">Enter halftime stats to calculate 2H probability.</p>
          </div>
          <div className="flex gap-1 shrink-0 mt-0.5">
            <Pill text="Pistons -6.5" />
            <Pill text="O/U 220.5" />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-[10px] text-white/35 font-medium tracking-wide uppercase">Player</label>
            <span className="text-[11px] text-blue-400 font-medium">CLE vs DET only</span>
          </div>
          <SelectRow value="Jalen Duren (C)" />
        </div>

        <div>
          <label className="text-[10px] text-white/35 font-medium tracking-wide uppercase block mb-1.5">Opponent Team</label>
          <SelectRow value="DET – Detroit Pistons" />
        </div>

        <div className="bg-[#111111] border border-white/[0.07] rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center gap-2 text-[10px] font-bold text-white/35 tracking-[0.1em] uppercase">
            <Clock size={10} />
            Game Situation
            <span className="flex items-center gap-1 text-emerald-400 normal-case tracking-normal font-semibold text-[10px]">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
              </span>
              Auto-filled
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <InputField label="Minutes Played" value="17" highlight />
            <InputField label="Fouls" value="1" highlight />
          </div>
          <div>
            <div className="flex items-center gap-1 text-[10px] text-white/25 mb-1.5">
              <Zap size={9} className="text-yellow-400/70" />
              Halftime Score (optional)
            </div>
            <InputField label="" value="56-55" />
          </div>
        </div>

        <div className="bg-[#111111] border border-white/[0.07] rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-white/35 tracking-[0.1em] uppercase">
            <CircleDot size={10} />
            The Line
          </div>
          <div>
            <label className="text-[10px] text-white/25 block mb-1.5">Stat / Prop Type</label>
            <SelectRow value="Pts+Reb" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <InputField label="Current Stat Total" value="19" highlight />
            <InputField label="Live Line" value="34.5" blueHighlight />
          </div>
        </div>
      </div>

      {/* Right */}
      <div className="flex-1 flex flex-col bg-[#080808] min-w-0">
        <div className="p-6 border-b border-white/[0.06]">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="text-[9px] font-bold text-white/25 tracking-[0.2em] uppercase mb-3">Live Prediction</div>
              <h3 className="text-[22px] font-extrabold text-white mb-2 leading-tight tracking-tight">
                Jalen Duren <span className="text-white/25">—</span> Pts+Reb{" "}
                <span className="text-blue-400">34.5</span>
              </h3>
              <div className="flex items-center gap-2 text-[12px] text-white/35 mb-3">
                <TrendingUp size={12} className="text-white/20" />
                At half: <span className="font-bold text-white/80 mx-0.5">19</span>
                <span className="text-white/15">·</span>
                Needs <span className="font-bold text-white/80 mx-0.5">15.5</span> more
              </div>
              <div className="flex items-center gap-4 text-[11px] text-white/30 mb-5 font-mono">
                <span>Season: <span className="text-white/60 font-semibold">18.2</span> PPG</span>
                <span><span className="text-white/60 font-semibold">10.6</span> RPG</span>
                <span><span className="text-white/60 font-semibold">1.7</span> APG</span>
                <span><span className="text-white/60 font-semibold">27.8</span> MPG</span>
              </div>
              <div className="flex gap-2.5">
                <ProbButton label="Over 34.5" pct="45%" positive />
                <ProbButton label="Under 34.5" pct="56%" positive={false} />
              </div>
            </div>

            {/* Blue gauge */}
            <div className="relative shrink-0">
              <svg width="128" height="128" viewBox="0 0 130 130" className="-rotate-90">
                <circle cx="65" cy="65" r={r} fill="none" stroke="#ffffff06" strokeWidth="10" />
                <circle
                  cx="65" cy="65" r={r}
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={circ}
                  strokeDashoffset={circ * (1 - hitPct)}
                  opacity={0.95}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-[28px] font-extrabold text-blue-400 leading-none tracking-normal font-sans">44.5%</span>
                <span className="text-[9px] text-white/25 uppercase tracking-[0.15em] mt-1">Hit Implied</span>
              </div>
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-red-500/15 border border-red-500/30 text-red-400 text-[9px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap">
                -6.7% EV
              </div>
            </div>
          </div>
        </div>

        {/* 5 Stat Cards */}
        <div className="grid grid-cols-5 divide-x divide-white/[0.05] border-b border-white/[0.06]">
          <StatCard label="Expected Total" value="33.1" valueClass="text-red-400" sub="Need: 34.5" icon={<CircleIcon />} />
          <StatCard label="Proj. Remaining Min" value="13.1" valueClass="text-white" sub="H2 Baseline" icon={<Clock size={12} className="text-white/20" />} />
          <StatCard label="Defense vs Pos" value="+2.0%" valueClass="text-emerald-400" sub="Opp allow vs position" icon={<Shield size={12} className="text-white/20" />} />
          <StatCard label="Game Pace" value="Above Avg" valueClass="text-red-400" valueSize="text-[15px]" sub="101.2 vs 101.2 pos/48" icon={<Zap size={12} className="text-white/20" />} />
          <StatCard label="vs Market" value="-6.7%" valueClass="text-red-400" sub="Model vs implied odds" icon={<TrendingUp size={12} className="text-white/20" />} />
        </div>

        {/* CLV Banner */}
        <div className="mx-5 mt-5 flex items-start justify-between bg-red-500/[0.07] border border-red-500/[0.18] rounded-xl p-4">
          <div className="flex items-start gap-3">
            <TrendingDown size={14} className="text-red-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-[12px] font-bold text-red-400 mb-1">Slight Under CLV — Model favors Under</p>
              <p className="text-[11px] text-white/40">
                Model probability: <span className="text-white/65">44.5%</span> · Book implied (DraftKings):{" "}
                <span className="text-white/65">51.2%</span> · Edge:{" "}
                <span className="text-red-400 font-semibold">-6.7%</span>
              </p>
              <p className="text-[10px] text-white/25 mt-1">
                Model trails the {"book's"} implied probability — line may already be priced in.
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold bg-red-500/15 border border-red-500/25 text-red-400 px-2 py-0.5 rounded-full shrink-0 ml-3">
            -6.7% EV
          </span>
        </div>

        {/* Live Pace Alert */}
        <div className="mx-5 mt-3 mb-5 flex items-center gap-3 bg-yellow-500/[0.06] border border-yellow-500/[0.15] rounded-xl p-3.5">
          <Zap size={13} className="text-yellow-400 shrink-0" />
          <div>
            <p className="text-[11px] font-bold text-yellow-400">Live Pace Active</p>
            <p className="text-[10px] text-white/30 mt-0.5">Game pace elevated in Q1 — projection adjusted upward by +1.8 pts</p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── TOP 2H PLAYS ────────────────────────────────────────────────── */
const TOP_PLAYS = [
  { rank: 1, player: "Dennis Schroder", matchup: "CLE vs DET", pct: "12.0%", edge: "+38.0%", prop: "Points U13.5", propType: "under", lineType: "Live Line", h1: "6", proj: "9.6", need: "7.5" },
  { rank: 2, player: "Dennis Schroder", matchup: "CLE vs DET", pct: "86.7%", edge: "+36.7%", prop: "3-Pointers Made O0.5", propType: "over", lineType: "Live Line", h1: "2", proj: "3.0", need: "—" },
  { rank: 3, player: "Daniss Jenkins", matchup: "DET vs CLE", pct: "21.3%", edge: "+28.7%", prop: "Points U7.9", propType: "under", lineType: "Season Avg", h1: "0", proj: "0.7", need: "7.9" },
  { rank: 4, player: "Duncan Robinson", matchup: "DET vs CLE", pct: "78.6%", edge: "+28.6%", prop: "3-Pointers Made O1.5", propType: "over", lineType: "Live Line", h1: "5 made", proj: "8.7", need: "0.5" },
  { rank: 5, player: "Caris LeVert", matchup: "DET vs CLE", pct: "22.5%", edge: "+27.5%", prop: "Points U7.7", propType: "under", lineType: "Season Avg", h1: "0", proj: "0.8", need: "7.7" },
  { rank: 6, player: "Dennis Schroder", matchup: "CLE vs DET", pct: "27.0%", edge: "+23.0%", prop: "Steals U1.5", propType: "under", lineType: "Season Avg", h1: "0", proj: "0.2", need: "1.5" },
];

function TopPlaysTab() {
  return (
    <div className="p-5 bg-[#080808]">
      <div className="flex items-start justify-between mb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Star size={15} className="text-blue-400" />
            <h2 className="text-[15px] font-extrabold text-white">Top 2H Plays — Full Slate</h2>
          </div>
          <p className="text-[11px] text-white/30">
            Top 20 plays by probability edge across all halftime games. Includes overs and unders.
          </p>
        </div>
        <button className="pointer-events-auto flex items-center gap-1.5 text-[11px] text-white/40 border border-white/[0.1] bg-white/[0.04] px-3 py-1.5 rounded-lg hover:text-white/60 transition-colors">
          <RefreshCw size={10} /> Refresh
        </button>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {TOP_PLAYS.map((play) => (
          <PlayCard key={play.rank} {...play} />
        ))}
      </div>
    </div>
  );
}

function PlayCard({
  rank, player, matchup, pct, edge, prop, propType, lineType, h1, proj, need,
}: {
  rank: number; player: string; matchup: string; pct: string; edge: string;
  prop: string; propType: string; lineType: string; h1: string; proj: string; need: string;
}) {
  const isHigh = parseFloat(pct) > 50;
  const pctColor = isHigh ? "text-emerald-400" : "text-red-400";
  const propBg = propType === "over"
    ? "bg-emerald-500/15 border-emerald-500/25 text-emerald-400"
    : "bg-red-500/15 border-red-500/25 text-red-400";

  return (
    <div className="bg-[#0f0f0f] border border-white/[0.08] rounded-xl p-4 flex flex-col gap-3 hover:border-white/[0.14] transition-colors">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-2.5">
          <div className="w-6 h-6 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shrink-0 mt-0.5">
            <span className="text-[9px] font-bold text-blue-400">#{rank}</span>
          </div>
          <div>
            <p className="text-[13px] font-bold text-white leading-tight">{player}</p>
            <p className="text-[11px] text-white/35 mt-0.5">{matchup}</p>
          </div>
        </div>
        <div className="text-right shrink-0">
          <p className={`text-[20px] font-extrabold leading-none font-mono ${pctColor}`}>{pct}</p>
          <p className="text-[10px] text-white/30 mt-0.5">Edge: <span className="text-emerald-400 font-semibold">{edge}</span></p>
        </div>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <span className={`text-[10px] font-bold border px-2 py-0.5 rounded ${propBg}`}>{prop}</span>
        <span className="text-[10px] font-medium text-white/40 border border-white/[0.1] bg-white/[0.04] px-2 py-0.5 rounded">{lineType}</span>
        <span className="text-[10px] text-white/25 font-mono ml-auto">H1: {h1} · Proj: {proj} · Need: {need}</span>
      </div>
      <button className="pointer-events-auto w-full flex items-center justify-center gap-1.5 text-[11px] font-semibold text-blue-400 bg-blue-600/10 border border-blue-500/20 rounded-lg py-2 hover:bg-blue-600/20 transition-colors">
        + Add to Parlay
      </button>
    </div>
  );
}

/* ─── SHARED HELPERS ──────────────────────────────────────────────── */
function NavButton({ icon, label, highlight, golden }: { icon: React.ReactNode; label: string; highlight?: boolean; golden?: boolean }) {
  const base = "flex items-center gap-1.5 text-[11px] font-semibold px-3 py-1.5 rounded-md border";
  if (highlight) return <div className={`${base} bg-blue-600 border-blue-500 text-white`}>{icon} {label}</div>;
  if (golden)    return <div className={`${base} bg-white/[0.04] border-white/[0.08] text-yellow-400`}>{icon} {label}</div>;
  return                 <div className={`${base} bg-white/[0.04] border-white/[0.08] text-white/50`}>{icon} {label}</div>;
}

function Pill({ text }: { text: string }) {
  return (
    <span className="text-[9px] font-bold bg-white/[0.06] border border-white/[0.1] text-white/60 px-1.5 py-0.5 rounded whitespace-nowrap">
      {text}
    </span>
  );
}

function SelectRow({ value }: { value: string }) {
  return (
    <div className="flex items-center justify-between bg-[#161616] border border-white/[0.09] rounded-lg px-3 py-2.5 text-[12px] text-white">
      {value}
      <ChevronDown size={12} className="text-white/25" />
    </div>
  );
}

function InputField({ label, value, placeholder, highlight, blueHighlight }: {
  label: string; value: string; placeholder?: string;
  highlight?: boolean; blueHighlight?: boolean;
}) {
  const borderClass = blueHighlight
    ? "border-blue-500/40 text-blue-400"
    : highlight
    ? "border-emerald-500/30 text-white"
    : "border-white/[0.07] text-white/60";
  return (
    <div>
      {label && <label className="text-[9px] text-white/25 block mb-1">{label}</label>}
      <div className={`bg-[#0a0a0a] border rounded-md px-3 py-1.5 text-[13px] font-mono ${borderClass}`}>
        {value || <span className="text-white/15">{placeholder}</span>}
      </div>
    </div>
  );
}

function ProbButton({ label, pct, positive }: { label: string; pct: string; positive: boolean }) {
  if (positive) {
    return (
      <div className="flex items-center gap-1.5 text-[12px] font-bold bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 px-3.5 py-2 rounded-lg">
        <TrendingUp size={12} /> {label} <span className="text-emerald-500/60">({pct})</span>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1.5 text-[12px] font-bold bg-red-500/10 border border-red-500/25 text-red-400 px-3.5 py-2 rounded-lg">
      <TrendingDown size={12} /> {label} <span className="text-red-500/60">({pct})</span>
    </div>
  );
}

function StatCard({ label, value, valueClass, valueSize = "text-[22px]", sub, icon }: {
  label: string; value: string; valueClass: string; valueSize?: string; sub: string; icon: React.ReactNode;
}) {
  return (
    <div className="p-4 flex flex-col gap-2 bg-[#080808]">
      <div className="flex items-center justify-between">
        <span className="text-[9px] text-white/30 font-medium leading-tight">{label}</span>
        {icon}
      </div>
      <div className={`${valueSize} font-extrabold ${valueClass} leading-none tracking-tight font-mono`}>{value}</div>
      <div className="text-[9px] text-white/20 font-mono">{sub}</div>
    </div>
  );
}

function CircleIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12">
      <circle cx="6" cy="6" r="5" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5" />
    </svg>
  );
}
